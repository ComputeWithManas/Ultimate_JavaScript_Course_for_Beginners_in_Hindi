# The Basic If Statement
The basic syntax for an `if` statement is as follows:
```js
if(condition){
    //code if condition is true
}
```
The `if` statement checks if the condition is true or false. If the condition is true, the code inside the `if` statement is executed. If the condition is false, the code inside the `if` statement is not executed.
