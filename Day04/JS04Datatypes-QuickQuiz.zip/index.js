// QuickQuiz of Datatypes
let obj = {
  Name: "Manas Agrawal",
  phoneNumber: 1234567890,
  Marks: 95,
}
console.log(obj);
console.log(obj["Name"]);
console.log(obj["phoneNumber"]);
console.log(obj["Marks"]);