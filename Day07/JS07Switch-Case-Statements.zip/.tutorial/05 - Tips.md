# Tips

 - Use `break` to prevent fall-through: Without `break`, the control will flow to the next case regardless of whether there is a match.
 - The `default` case is optional but can be useful for handling unexpected values.
