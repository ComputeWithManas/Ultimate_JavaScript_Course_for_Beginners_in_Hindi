# Practice Set 1
Now that we've covered the basics of JavaScript, it's time to put our knowledge to the test. In this practice set, we'll cover a range of topics from variables to objects.
