## Q5: Month dictionary
Create a JavaScript program to make a month dictionary like 1 = January, 2 = February, and so on.

<details><summary>Answer</summary>

```javascript
const months = {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: "May",
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December"
};
```
</details> </br>

Congratulations, you've completed Practice Set 1! If you got everything correct, great job! If not, don't worry - practice makes perfect. Keep practicing and you'll get there.