// Question-1
let name = "Manas";
let age = 15;
console.log(name + age); // Output: Manas15

// Question-2
console.log(typeof str)
console.log(typeof name)

// Question-3
const biodata = { 
    name: "Manas",
    age: 15,
};

// Question-4
biodata.number = 123456789
// biodata = 29; // TypeError: Assignment to constant variable.
console.log(biodata)

// Question-5
const months = {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: "May",
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December"
};
console.log(months)