// Operators in JavaScript
console.log("Operators in JavaScript");
// Arithmatic Operators
// console.log("Arithmatic Operators");
// let a = 5;
// let b = 3;

// console.log("a + b =", a + b); // Addition
// console.log("a - b =", a - b); // Subtraction
// console.log("a * b =", a * b); // Multiplication
// console.log("a / b =", a / b); // Division
// console.log("a ** b =", a ** b); // Exponentiation
// console.log("a % b =", a % b); // Modulus
// console.log("a++ =", a++); // Increment
// console.log("a-- =", a--); // Decrement

// Assignment Operators
// let assignment = 12
// assignment += 5// same as assignment = assignment + 5
// assignment -= 5// same as assignment = assignment - 5
// assignment *= 5// same as assignment = assignment * 5
// assignment /= 5// same as assignment = assignment / 5
// assignment %= 5// same as assignment = assignment % 5
// assignment **= 2// same as assignment = assignment ** 5
// console.log(assignment)

// Comparison Operators
// let com1 = 5;
// let com2 = 10;
// console.log("com1 == com2 is ", com1 == com2);
// console.log("com1 != com2 is ", com1 != com2);
// console.log("com1 === com2 is ", com1 === com2);
// console.log("com1 !== com2 is ", com1 !== com2);
// console.log("com1 > com2 is ", com1 > com2);
// console.log("com1 < com2 is ", com1 < com2);
// console.log("com1 >= com2 is ", com1 >= com2);
// console.log("com1 <= com2 is ", com1 <= com2);
// const age = Number.parseInt(prompt("Enter your Age"));
// const message = (age >= 18) ? "You are an adult" : "You are not an adult";
// console.log(message);

// Logical Operators
// const a = 10;
// const b = 20;
// const c = 30;
// console.log(a < b && b < c); // true
// console.log(a < b && b > c); // false
// const x = 5;
// const y = 10;
// console.log(x > 3 || y < 5); // true
// console.log(x < 3 || y < 5); // false
// const z = 10;
// console.log(!(z > 5)); // false
// console.log(!(z < 5)); // true

// Taking User Input
// let a = parseInt(prompt("Enter your Name"));
// console.log(typeof a);

// Conditional Statements
// If Statements
// let age = Number.parseInt(prompt("Enter yor Age"));
// if (age < 18) {
// 	console.log("You cannot Drive");
// }
// console.log("123");

// If-Else Statement
// let age = Number.parseInt(prompt("Enter yor Age"));
// if (age < 18) {
// 	console.log("You cannot Drive");
// }
// else {
// 	console.log("You cannot Drive");
// }
// console.log("123");

// If-ElseIf-Else Statements
// let age = Number.parseInt(prompt("Enter yor Age"));
// if (age < 0) {
// 	console.log("This is not a valid age");
// }
// else if (age < 10) {
// 	console.log("You cannot drive");
// }
// else if (age < 18) {
// 	console.log("You can now think of driving after 18");
// }
// else {
// 	console.log("You can Drive");
// }