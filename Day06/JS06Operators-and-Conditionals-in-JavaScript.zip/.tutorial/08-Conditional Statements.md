# Conditional Statements
Conditional statements are used to perform different actions based on different conditions. In JavaScript, we have the following conditional statements:

For example, when you log in to Instagram, you can use email or username. If you use email, your program might know that it should search in the place where you stored emails, and if you use a username, it should search in the place where you stored usernames.

* `if` statement
* `if-else` statement
* `if else-if else` statement
